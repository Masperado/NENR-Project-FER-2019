package hr.fer.zemris.fuzzy.sets;

public interface IBinaryFunction {

    double valueAt(double a, double b);
}
