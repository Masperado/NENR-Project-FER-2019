package hr.fer.zemris.fuzzy.sets;

public interface IIntUnaryFUnction {

    double valueAt(int element);
}
