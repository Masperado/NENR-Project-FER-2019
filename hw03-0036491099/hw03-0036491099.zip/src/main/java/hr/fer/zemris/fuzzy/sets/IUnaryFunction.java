package hr.fer.zemris.fuzzy.sets;

public interface IUnaryFunction {

    double valueAt(double a);

}
