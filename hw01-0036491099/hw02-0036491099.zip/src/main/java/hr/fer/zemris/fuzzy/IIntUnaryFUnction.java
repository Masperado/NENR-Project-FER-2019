package hr.fer.zemris.fuzzy;

public interface IIntUnaryFUnction {

    double valueAt(int element);
}
