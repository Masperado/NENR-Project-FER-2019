package hr.fer.zemris.fuzzy;

public interface IBinaryFunction {

    double valueAt(double a, double b);
}
