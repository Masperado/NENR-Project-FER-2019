package hr.fer.zemris.optjava.dz4.api;

public interface ICrossing<T> {

	T[] cross(T parent1, T parent2);

}
