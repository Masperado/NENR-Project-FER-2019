package hr.fer.zemris.nenr.genetic.api;

public interface IFunction<T> {

	double valueAt(T point);

}
