package hr.fer.zemris.nenr.network.api;

public interface ITransferFunction {

	public double valueAt(double x);

}
